//
// Created by Ernst, Michael 11.12.2020.
//

#ifndef ADVENT2020_CHALLENGE_DAY1_H
#define ADVENT2020_CHALLENGE_DAY1_H

// prototype:
int findValue();

#endif //ADVENT2020_CHALLENGE_DAY1_H
