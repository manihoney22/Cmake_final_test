//
// Created by Ernst, Michael on 11.12.2020.
//

#include <iostream>
#include "day1.h"


using namespace std;

int main() {
    cout << "Day 1 Puzzle 1" << std::endl;
    findValue();
    return 0;
}
