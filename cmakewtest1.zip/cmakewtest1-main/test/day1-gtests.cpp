
#include <iostream>
#include <list>
#include <string>


#include "../StringHelper.cpp"
#include "../FileLoader.cpp"
#include "../day1.h"
#include "../StringHelper.h"
#include <gtest/gtest.h>
#include "../day1.cpp"
#include "../FileLoader.h"

TEST(day1_test_1, debug) {
    // DUMMY Test
    ASSERT_EQ(findValue(), 605364);
}

TEST(day1_test_2, debug) {
// DUMMY Test
ASSERT_EQ(findValue()+1, 605364+1);
}

TEST(day1_test_3, debug) {
// DUMMY Test
ASSERT_EQ(findValue()+2, 605364+2);
}

